/**
 * Kontrollija
 */
public interface Kontrollija {
    public void salvestaViivis(String laenutajaNimi, String teoseKirjeldus, double viiviseSuurus);
}