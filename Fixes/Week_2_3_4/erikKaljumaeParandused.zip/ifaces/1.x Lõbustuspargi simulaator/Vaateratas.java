/**
 * Vaateratas
 */
public class Vaateratas implements Lobustus {

    public void lobusta(Kylastaja isik) {
        isik.lisaKirjeldus("külastasin vaateratast");
    }
}