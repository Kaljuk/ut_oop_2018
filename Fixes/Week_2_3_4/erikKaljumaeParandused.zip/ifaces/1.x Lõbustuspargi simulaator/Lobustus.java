/**
 * Lobustus
 */
public interface Lobustus {
    public void lobusta(Kylastaja isik);
}